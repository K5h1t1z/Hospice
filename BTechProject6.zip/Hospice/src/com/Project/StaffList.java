package com.Project;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/StaffList")
public class StaffList extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {e.printStackTrace();}
		try {
			
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/GMC", "root", "Spark@3000");
			Statement st= con.createStatement();
			ResultSet rs= st.executeQuery("select * from Staff order by FullName;");
			rs.next();
			
			HttpSession ses= req.getSession();
			ses.setAttribute("rs", rs);

			res.sendRedirect("StaffList.jsp");
		} catch (SQLException e) {e.printStackTrace();}
		
	}//ME

}
